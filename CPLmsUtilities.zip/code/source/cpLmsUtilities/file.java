package cpLmsUtilities;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.softwareag.util.IDataMap;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.FileSystem;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileAttribute;
import java.nio.file.attribute.PosixFilePermission;
import java.nio.file.attribute.PosixFilePermissions;
import java.nio.file.attribute.UserPrincipal;
import java.nio.file.attribute.UserPrincipalLookupService;
import java.util.Set;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;
// --- <<IS-END-IMPORTS>> ---

public final class file

{
	// ---( internal utility methods )---

	final static file _instance = new file();

	static file _newInstance() { return new file(); }

	static file _cast(Object o) { return (file)o; }

	// ---( server methods )---




	public static final void crearDirectorio (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(crearDirectorio)>> ---
		// @sigtype java 3.5
		// [i] field:0:required ruta
		// [i] field:0:required usuario
		IDataMap idm = new IDataMap(pipeline);
		Path pathDirectory = Paths.get(idm.getAsString("ruta"));
		String ownerDirectory = idm.getAsString("usuario");
		try {
			if (!Files.exists(pathDirectory)){
				Set<PosixFilePermission> permissions = PosixFilePermissions.fromString("rwxrw-rw-");
				FileAttribute<Set<PosixFilePermission>> fileAttributes = PosixFilePermissions.asFileAttribute(permissions);
				
				FileSystem fileSystem = pathDirectory.getFileSystem();
		        UserPrincipalLookupService service = fileSystem.getUserPrincipalLookupService();
		        UserPrincipal userPrincipal = service.lookupPrincipalByName(ownerDirectory);
				
				Files.createDirectory(pathDirectory, fileAttributes);
				Files.setOwner(pathDirectory, userPrincipal);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
			
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---

	
	// --- <<IS-END-SHARED>> ---
}

